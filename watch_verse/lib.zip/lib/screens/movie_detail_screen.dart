import 'package:flutter/material.dart';
import 'package:watch_verse/models/model.dart';

class MovieDetailsScreen extends StatefulWidget {
  final Movie movie;

  const MovieDetailsScreen({super.key, required this.movie});

  @override
  State<MovieDetailsScreen> createState() => _MovieDetailsScreenState();
}

class _MovieDetailsScreenState extends State<MovieDetailsScreen> {
  bool _isAddedToWatchlist = false; // Initially, the movie is not in the watchlist

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.movie.title),
        actions: [
          IconButton(
            icon: Icon(
              _isAddedToWatchlist ? Icons.check : Icons.add,
            ),
            onPressed: () {
              setState(() {
                _isAddedToWatchlist = !_isAddedToWatchlist;
              });

              // TODO: Implement adding/removing movie from the watchlist
              // This is where you would call your API or update your database
              if (_isAddedToWatchlist) {
                // Add movie to watchlist
                print('${widget.movie.title} added to watchlist');
              } else {
                // Remove movie from watchlist
                print('${widget.movie.title} removed from watchlist');
              }
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.network(
                "https://image.tmdb.org/t/p/w500/${widget.movie.posterPath}",
                fit: BoxFit.cover,
              ),
              const SizedBox(height: 16),
              Text(
                widget.movie.title,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text("Yayın Tarihi: ${widget.movie.releaseDate}"),
              const SizedBox(height: 8),
              Text("Puan: ${widget.movie.voteAverage}"),
              const SizedBox(height: 16),
              const Text(
                "Özet:",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(widget.movie.overview),
            ],
          ),
        ),
      ),
    );
  }
}